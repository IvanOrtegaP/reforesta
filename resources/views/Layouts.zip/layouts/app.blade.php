<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
</head>
<body>
    @include('notas.navbar')
    <div class="content">
        @yield('content')
    </div>

    <h1 class="text-center mb-4">REFORESTA</h1>
    <nav class="mb-4">
        <a href="{{ route('usuarios.index') }}" class="btn btn-primary">Usuarios</a>
        <a href="{{ route('especies.index') }}" class="btn btn-success">Especies</a>
        <a href="{{ route('eventos.index') }}" class="btn btn-warning">Eventos</a>
    </nav>
</body>
</html>
