@extends('layouts.app')

@section('title', 'Especies')

@section('content')
    <h2>Especies</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre Científico</th>
                <th>Región</th>
                <th>Clima</th>
                <th>Enlace</th>
                <th>Foto</th>
            </tr>
        </thead>
        <tbody>
            @foreach($especies as $especie)
                <tr>
                    <td>{{ $especie->id }}</td>
                    <td>{{ $especie->nombre_cientifico }}</td>
                    <td>{{ $especie->region }}</td>
                    <td>{{ $especie->clima }}</td>
                    <td>{{ $especie->enlace }}</td>
                    <td>
                        @if($especie->foto)
                            <img src="{{ asset('images/' . $especie->foto) }}" alt="Foto" width="100">
                        @else
                            N/A
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
