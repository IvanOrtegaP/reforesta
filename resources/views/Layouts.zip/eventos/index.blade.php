@extends('layouts.app')

@section('title', 'Eventos')

@section('content')
    <h2>Eventos</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Ubicación</th>
                <th>Fecha</th>
                <th>Tipo</th>
                <th>Terreno</th>
                <th>Organizador</th>
                <th>Participantes</th>
                <th>Especies Usadas</th>
            </tr>
        </thead>
        <tbody>
            @foreach($eventos as $evento)
                <tr>
                    <td>{{ $evento->id }}</td>
                    <td>{{ $evento->nombre }}</td>
                    <td>{{ $evento->ubicacion }}</td>
                    <td>{{ $evento->fecha }}</td>
                    <td>{{ $evento->tipo_evento }}</td>
                    <td>{{ $evento->t_terreno }}</td>
                    <td>{{ $evento->organizador->nombre ?? 'N/A' }}</td>
                    <td>
                        @if($evento->participantes->isNotEmpty())
                            <ul>
                                @foreach($evento->participantes as $participante)
                                    <li>{{ $participante->nombre }}</li>
                                @endforeach
                            </ul>
                        @else
                            No hay participantes
                        @endif
                    </td>
                    <td>
                        @if($evento->especies->isNotEmpty())
                            <ul>
                                @foreach($evento->especies as $especie)
                                    <li>{{ $especie->nombre_cientifico }} ({{ $especie->pivot->cantidad }})</li>
                                @endforeach
                            </ul>
                        @else
                            No hay especies registradas
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection