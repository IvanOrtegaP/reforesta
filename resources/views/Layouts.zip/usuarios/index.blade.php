@extends('layouts.app')

@section('title', 'Usuarios')

@section('content')
    <h2>Usuarios</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nick</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Karma</th>
            </tr>
        </thead>
        <tbody>
            @foreach($usuarios as $usuario)
                <tr>
                    <td>{{ $usuario->id }}</td>
                    <td>{{ $usuario->nick }}</td>
                    <td>{{ $usuario->nombre }}</td>
                    <td>{{ $usuario->email }}</td>
                    <td>{{ $usuario->karma }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
